
# What is this ?
This is a Dummy Medical website Theme Which i made using BootStrap5.

<hr>

> You may also be intrested in My [BootStrap5 "Food Themed" project](https://github.com/abolfazlchaman/FoodMazeh-BootStrap5) !

<hr>

* I have closed issues, Please [Email me](mailto:abolfazlchaman.info@gmail.com)  If you find any issues.

* This is a "Dummy project", no contribution is needed!
